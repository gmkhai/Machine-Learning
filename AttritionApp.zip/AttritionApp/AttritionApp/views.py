from django.shortcuts import redirect,render
from django.views.generic.base import View
from .Backend.PredictEmployees import PredictEmployees

class IndexView(View):
    template_name='main/IndexTemplates.html'
    def get(self,*args,**kwargs):
        return render(self.request,self.template_name)

class FormView(View):
    template_name='main/FormTemplates.html'
    def get(self,*args,**kwargs):
        return render(self.request,self.template_name)

    #fungsi ini untuk mengambil data dari template html yang telah dibuat ini untuk halaman FormTemplates.html
    def post(self,*args,**kwargs):
        #nama disesuaikan dengan name di halaman formulir di file FormTemplates.html
        nama_depan=self.request.POST['nama_depan']
        nama_belakang=self.request.POST['nama_belakang']
        jenis_kelamin=self.request.POST.get('jenis_kelamin')
        status_pernikahan=self.request.POST.get('status_pernikahan')
        umur=self.request.POST['umur']
        jarak_rumah=self.request.POST['jarak_rumah']
        bidang_pendidikan=self.request.POST['bidang_pendidikan']
        pendidikan=self.request.POST['pendidikan']
        nomor_karyawan=self.request.POST['nomor_karyawan']
        departement=self.request.POST['departement']
        peran_pekerjaan=self.request.POST['peran_pekerjaan']
        level_pekerjaan=self.request.POST['level_pekerjaan']
        keterlibatan=self.request.POST['keterlibatan']
        tahun_perusahaan=self.request.POST['tahun_perusahaan']
        tahun_peran=self.request.POST['tahun_peran']
        tahun_promosi=self.request.POST['tahun_promosi']
        tahun_manager=self.request.POST['tahun_manager']
        waktu_pelatihan=self.request.POST['waktu_pelatihan']
        total_kerja=self.request.POST['total_kerja']
        jumlah_perusahaan=self.request.POST['jumlah_perusahaan']
        tarif_harian=self.request.POST['tarif_harian']
        pendapatan_bulanan=self.request.POST['pendapatan_bulanan']
        tarif_bulanan=self.request.POST['tarif_bulanan']
        persen_kenaikan=self.request.POST['persen_kenaikan']
        status_lembur=self.request.POST.get('status_lembur')
        opsi_saham=self.request.POST['opsi_saham']
        keseimbangan_kerja=self.request.POST['keseimbangan_kerja']
        kepuasan_hubungan=self.request.POST['kepuasan_hubungan']
        kepuasan_lingkungan=self.request.POST['kepuasan_lingkungan']
        kepuasan_bekerja=self.request.POST['kepuasan_bekerja']

        #instance untuk memanggil class employees
        employees=PredictEmployees([nama_depan,
        nama_belakang,
        nomor_karyawan,
        umur,
        tarif_harian,
        departement,
        jarak_rumah,
        pendidikan,
        bidang_pendidikan,
        kepuasan_lingkungan,
        jenis_kelamin,
        keterlibatan,
        level_pekerjaan,
        peran_pekerjaan,
        kepuasan_bekerja,
        status_pernikahan,
        pendapatan_bulanan,
        tarif_bulanan,
        jumlah_perusahaan,
        status_lembur,
        persen_kenaikan,
        kepuasan_hubungan,
        opsi_saham,
        total_kerja,
        waktu_pelatihan,
        keseimbangan_kerja,
        tahun_perusahaan,
        tahun_peran,
        tahun_promosi,
        tahun_manager,
        ])
        context={
            'handling':'open',
            'prediksi_keluar': f"{employees.prediksi()[1]:.2f}",
            'prediksi_tidak':f"{employees.prediksi()[0]:.2f}"
        }
        return render(self.request,self.template_name,context)

