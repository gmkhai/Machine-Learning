from sklearn.preprocessing import StandardScaler
import pandas as pd
import numpy as np
import joblib
class PredictEmployees:
    
    def __init__(self,feature):
        self.feature=feature

    # Melakukan preprocessing seperti pemilihan atribut, dan parse tipe data dari string ke integer
    def preprocessing(self):
        nama_depan=self.feature[0]
        nama_belakang=self.feature[1]
        nomor_karyawan=self.feature[2]
        data_parse_integer=[]
        i=0
        while i < len(self.feature):
            if i > 2:
                data_parse_integer.append(int(self.feature[i]))
            i+=1
        return data_parse_integer

    #Penerapan model yang telah dilatih
    def prediksi(self):
        models_saved=joblib.load("./models/employee-knn.sav")
        X = pd.DataFrame(
            [self.preprocessing()], #ini samakan dengan atribut di codingan pembuatan modelnya samakan dengan yang didataset
            columns = ["Age",
            "DailyRate",
            "Department",
            "DistanceFromHome",
            "Education",
            "EducationField",
            "EnvironmentSatisfaction",
            "Gender",
            "JobInvolvement",
            "JobLevel",
            "JobRole",
            "JobSatisfaction",
            "MaritalStatus",
            "MonthlyIncome",
            "MonthlyRate",
            "NumCompaniesWorked",
            "OverTime",
            "PercentSalaryHike",
            "RelationshipSatisfaction",
            "StockOptionLevel",
            "TotalWorkingYears",
            "TrainingTimesLastYear",
            "WorkLifeBalance",
            "YearsAtCompany",
            "YearsInCurrentRole",
            "YearsSinceLastPromotion",
            "YearsWithCurrManager",
            ]) 
        hasil_prediksi=models_saved.predict_proba(X)[0]
        probabilitas=hasil_prediksi*100
        return probabilitas