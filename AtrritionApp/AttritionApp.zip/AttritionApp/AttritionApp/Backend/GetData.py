import pandas as pd
import requests

class AttritionClass:

    def ExtractData():
        id_data=[]
        nama_depan=[]
        nama_belakang=[]
        nomor_karyawan=[]
        Age=[]
        DailyRate=[]
        Department=[]
        DistanceFromHome=[]
        Education=[]
        EducationField=[]
        EnvironmentSatisfaction=[]
        Gender=[]
        JobInvolvement=[]
        JobLevel=[]
        JobRole=[]
        JobSatisfaction=[]
        MaritalStatus=[]
        MonthlyIncome=[]
        MonthlyRate=[]
        NumCompaniesWorked=[]
        OverTime=[]
        PercentSalaryHike=[]
        RelationshipSatisfaction=[]
        StockOptionLevel=[]
        TotalWorkingYears=[]
        TrainingTimesLastYear=[]
        WorkLifeBalance=[]
        YearsAtCompany=[]
        YearsInCurrentRole=[]
        YearsSinceLastPromotion=[]
        YearsWithCurrManager=[]
        data_attrition = requests.get('http://localhost:8000/employees/api').json()
        i=0
        while i < len(data_attrition):
            id_data.append(i)
            nama_depan.append(data_attrition[i]['nama_depan'])
            nama_belakang.append(data_attrition[i]['nama_belakang'])
            nomor_karyawan.append(data_attrition[i]['nomor_karyawan'])
            Age.append(data_attrition[i]['Age'])
            DailyRate.append(data_attrition[i]['DailyRate'])
            Department.append(data_attrition[i]['Department'])
            DistanceFromHome.append(data_attrition[i]['DistanceFromHome'])
            Education.append(data_attrition[i]['Education'])
            EducationField.append(data_attrition[i]['EducationField'])
            EnvironmentSatisfaction.append(data_attrition[i]['EnvironmentSatisfaction'])
            Gender.append(data_attrition[i]['Gender'])
            JobInvolvement.append(data_attrition[i]['JobInvolvement'])
            JobLevel.append(data_attrition[i]['JobLevel'])
            JobRole.append(data_attrition[i]['JobRole'])
            JobSatisfaction.append(data_attrition[i]['JobSatisfaction'])
            MaritalStatus.append(data_attrition[i]['MaritalStatus'])
            MonthlyIncome.append(data_attrition[i]['MonthlyIncome'])
            MonthlyRate.append(data_attrition[i]['MonthlyRate'])
            NumCompaniesWorked.append(data_attrition[i]['NumCompaniesWorked'])
            OverTime.append(data_attrition[i]['OverTime'])
            PercentSalaryHike.append(data_attrition[i]['PercentSalaryHike'])
            RelationshipSatisfaction.append(data_attrition[i]['RelationshipSatisfaction'])
            StockOptionLevel.append(data_attrition[i]['StockOptionLevel'])
            TotalWorkingYears.append(data_attrition[i]['TotalWorkingYears'])
            TrainingTimesLastYear.append(data_attrition[i]['TrainingTimesLastYear'])
            WorkLifeBalance.append(data_attrition[i]['WorkLifeBalance'])
            YearsAtCompany.append(data_attrition[i]['YearsAtCompany'])
            YearsInCurrentRole.append(data_attrition[i]['YearsInCurrentRole'])
            YearsSinceLastPromotion.append(data_attrition[i]['YearsSinceLastPromotion'])
            YearsWithCurrManager.append(data_attrition[i]['YearsWithCurrManager'])
            i+=1
        
        data_frame=pd.DataFrame({
            'id_data':id_data,
            'nama_depan':nama_depan,
            'nama_belakang':nama_belakang,
            'nomor_karyawan':nomor_karyawan,
            'Age':Age,
            'DailyRate':DailyRate,
            'Department':Department,
            'DistanceFromHome':DistanceFromHome,
            'Education':Education,
            'EducationField':EducationField,
            'EnvironmentSatisfaction':EnvironmentSatisfaction,
            'Gender':Gender,
            'JobInvolvement':JobInvolvement,
            'JobLevel':JobLevel,
            'JobRole':JobRole,
            'JobSatisfaction':JobSatisfaction,
            'MaritalStatus':MaritalStatus,
            'MonthlyIncome':MonthlyIncome,
            'MonthlyRate':MonthlyRate,
            'NumCompaniesWorked':NumCompaniesWorked,
            'OverTime':OverTime,
            'PercentSalaryHike':PercentSalaryHike,
            'RelationshipSatisfaction':RelationshipSatisfaction,
            'StockOptionLevel':StockOptionLevel,
            'TotalWorkingYears':TotalWorkingYears,
            'TrainingTimesLastYear':TrainingTimesLastYear,
            'WorkLifeBalance':WorkLifeBalance,
            'YearsAtCompany':YearsAtCompany,
            'YearsInCurrentRole':YearsInCurrentRole,
            'YearsSinceLastPromotion':YearsSinceLastPromotion,
            'YearsWithCurrManager':YearsWithCurrManager,
            }
        )
        return data_frame.to_csv('dummy_data.csv')
    def TransformData(self):
        return self.TransformData()
    def LoadData(self):
        return self.LoadData()
    
    print(ExtractData())
    
