from employees.models import Employees


class CreateEmployees:
    def __init__(self,data_employees):
        self.data_employees=data_employees
    
    #konversi data dari string to integer
    def parseInteger(self):
        data_parse=[
            self.data_employees[0],
            self.data_employees[1],
            self.data_employees[2],
            
            ]
        i=0
        while i<len(self.data_employees):
            if i > 2:
                data_parse.append(int(self.data_employees[i]))
            i+=1
        return data_parse
    
    #save data ke database
    def saveData(self):
        saveEmployees=Employees.objects.create(
            nama_depan=self.parseInteger()[0],
            nama_belakang=self.parseInteger()[1],
            nomor_karyawan=self.parseInteger()[2],
            Age=self.parseInteger()[3],
            DailyRate=self.parseInteger()[4],
            Department=self.parseInteger()[5],
            DistanceFromHome=self.parseInteger()[6],
            Education=self.parseInteger()[7],
            EducationField=self.parseInteger()[8],
            EnvironmentSatisfaction=self.parseInteger()[9],
            Gender=self.parseInteger()[10],
            JobInvolvement=self.parseInteger()[11],
            JobLevel=self.parseInteger()[12],
            JobRole=self.parseInteger()[13],
            JobSatisfaction=self.parseInteger()[14],
            MaritalStatus=self.parseInteger()[15],
            MonthlyIncome=self.parseInteger()[16],
            MonthlyRate=self.parseInteger()[17],
            NumCompaniesWorked=self.parseInteger()[18],
            OverTime=self.parseInteger()[19],
            PercentSalaryHike=self.parseInteger()[20],
            RelationshipSatisfaction=self.parseInteger()[21],
            StockOptionLevel=self.parseInteger()[22],
            TotalWorkingYears=self.parseInteger()[23],
            TrainingTimesLastYear=self.parseInteger()[24],
            WorkLifeBalance=self.parseInteger()[25],
            YearsAtCompany=self.parseInteger()[26],
            YearsInCurrentRole=self.parseInteger()[27],
            YearsSinceLastPromotion=self.parseInteger()[28],
            YearsWithCurrManager=self.parseInteger()[29],
        )
        return saveEmployees.save()