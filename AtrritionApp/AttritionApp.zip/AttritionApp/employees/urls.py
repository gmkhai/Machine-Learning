from django.urls import path
from .views import EmployeeListApiView

urlpatterns=[
    path('api',EmployeeListApiView.as_view())


]