from django.contrib.auth.models import User
from django.db import models

class Employees(models.Model):
    nama_depan=models.CharField(max_length=50)
    nama_belakang=models.CharField(max_length=50)
    nomor_karyawan=models.CharField(max_length=50)
    Age=models.IntegerField()
    DailyRate=models.IntegerField()
    Department=models.IntegerField()
    DistanceFromHome=models.IntegerField()
    Education=models.IntegerField()
    EducationField=models.IntegerField()
    EnvironmentSatisfaction=models.IntegerField()
    Gender=models.IntegerField()
    JobInvolvement=models.IntegerField()
    JobLevel=models.IntegerField()
    JobRole=models.IntegerField()
    JobSatisfaction=models.IntegerField()
    MaritalStatus=models.IntegerField()
    MonthlyIncome=models.IntegerField()
    MonthlyRate=models.IntegerField()
    NumCompaniesWorked=models.IntegerField()
    OverTime=models.IntegerField()
    PercentSalaryHike=models.IntegerField()
    RelationshipSatisfaction=models.IntegerField()
    StockOptionLevel=models.IntegerField()
    TotalWorkingYears=models.IntegerField()
    TrainingTimesLastYear=models.IntegerField()
    WorkLifeBalance=models.IntegerField()
    YearsAtCompany=models.IntegerField()
    YearsInCurrentRole=models.IntegerField()
    YearsSinceLastPromotion=models.IntegerField()
    YearsWithCurrManager=models.IntegerField()
    user = models.ForeignKey(User, on_delete = models.CASCADE, blank = True, null = True)
    
    def __str__(self):
        return self.user