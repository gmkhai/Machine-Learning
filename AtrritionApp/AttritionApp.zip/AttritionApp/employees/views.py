from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework import permissions
from .models import Employees
from .EmployeeSerializer import EmployeeSerializer

class EmployeeListApiView(APIView):
    def get(self, request, *args, **kwargs):
        employee = Employees.objects.all()
        serializer = EmployeeSerializer(employee, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
