from rest_framework import serializers
from .models import Employees
class EmployeeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Employees
        fields = [
            "nama_depan",
            "nama_belakang",
            "nomor_karyawan",
            "Age",
            "DailyRate",
            "Department",
            "DistanceFromHome",
            "Education",
            "EducationField",
            "EnvironmentSatisfaction",
            "Gender",
            "JobInvolvement",
            "JobLevel",
            "JobRole",
            "JobSatisfaction",
            "MaritalStatus",
            "MonthlyIncome",
            "MonthlyRate",
            "NumCompaniesWorked",
            "OverTime",
            "PercentSalaryHike",
            "RelationshipSatisfaction",
            "StockOptionLevel",
            "TotalWorkingYears",
            "TrainingTimesLastYear",
            "WorkLifeBalance",
            "YearsAtCompany",
            "YearsInCurrentRole",
            "YearsSinceLastPromotion",
            "YearsWithCurrManager",
            "user"
        ]